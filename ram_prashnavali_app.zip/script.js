
const grid = document.getElementById("grid");
const resultDiv = document.getElementById("result");
const chopaiEl = document.getElementById("chopai");
const meaningEl = document.getElementById("meaning");

let ids = Array.from({ length: 36 }, (_, i) => "ID" + (i + 1));

function createGrid() {
  ids.forEach((id) => {
    const btn = document.createElement("button");
    btn.innerText = id;
    btn.onclick = () => showResult(id);
    grid.appendChild(btn);
  });
}

async function showResult(id) {
  const res = await fetch("ram_prashnavali_results.json");
  const data = await res.json();
  const item = data[id];
  chopaiEl.innerText = `चौपाई: ${item.chopai}`;
  meaningEl.innerText = `भावार्थ: ${item.meaning}`;
  resultDiv.classList.remove("hidden");
  grid.innerHTML = "";
}

function resetGrid() {
  resultDiv.classList.add("hidden");
  grid.innerHTML = "";
  createGrid();
}

createGrid();
